package facade.use;

/**
 * 使用外观模式的情况
 * Created by LinkinStar
 */
public class MainTest {

    public static void main(String[] args) {
        Facade facade = new Facade();
        facade.execute();
    }
}
