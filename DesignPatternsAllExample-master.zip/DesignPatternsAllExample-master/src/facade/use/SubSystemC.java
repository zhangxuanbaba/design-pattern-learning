package facade.use;

/**
 * 子系统C
 * Created by LinkinStar
 */
public class SubSystemC {
    public void stepOne(){
        System.out.println("步骤3");
    }
    public void stepTwo(){
        System.out.println("步骤6");
    }
}
