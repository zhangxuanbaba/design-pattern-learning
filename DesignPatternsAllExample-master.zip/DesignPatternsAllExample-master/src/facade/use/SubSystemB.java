package facade.use;

/**
 * 子系统B
 * Created by LinkinStar
 */
public class SubSystemB {
    public void stepOne(){
        System.out.println("步骤2");
    }
    public void stepTwo(){
        System.out.println("步骤5");
    }
}
