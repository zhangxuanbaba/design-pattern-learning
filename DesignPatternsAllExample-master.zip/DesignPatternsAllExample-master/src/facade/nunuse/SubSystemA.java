package facade.nunuse;

/**
 * 子系统A
 * Created by LinkinStar
 */
public class SubSystemA {
    public void stepOne(){
        System.out.println("步骤1");
    }
    public void stepTwo(){
        System.out.println("步骤4");
    }
}
