package proxy.use;

/**
 * 被代理对象的接口
 * Created by LinkinStar
 */
public interface Subject {
    void dis(int val);
}
