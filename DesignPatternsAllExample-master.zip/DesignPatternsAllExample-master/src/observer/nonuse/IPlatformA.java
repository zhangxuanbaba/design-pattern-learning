package observer.nonuse;

/**
 * A平台所给出的接口
 * Created by LinkinStar
 */
public interface IPlatformA {
    void update(String message);
}
