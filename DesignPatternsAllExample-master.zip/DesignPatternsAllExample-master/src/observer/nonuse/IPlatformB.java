package observer.nonuse;

/**
 * B平台所给出的接口
 * Created by LinkinStar
 */
public interface IPlatformB {
    void update(String message);
}
