package simpleFactory.nunuse;

/**
 * 香蕉
 * Created by LinkinStar
 */
public class Banana {
    public void dis(){
        System.out.println("香蕉");
    }
}
