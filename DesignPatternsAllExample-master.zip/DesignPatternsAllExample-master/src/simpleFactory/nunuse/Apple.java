package simpleFactory.nunuse;

/**
 * 苹果
 * Created by LinkinStar
 */
public class Apple {
    public void dis(){
        System.out.println("苹果");
    }
}
