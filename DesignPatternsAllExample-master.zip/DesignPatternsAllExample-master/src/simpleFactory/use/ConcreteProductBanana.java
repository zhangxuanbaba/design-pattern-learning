package simpleFactory.use;

/**
 * 具体产品角色-香蕉
 * Created by LinkinStar
 */
public class ConcreteProductBanana implements Product {
    public void dis(){
        System.out.println("香蕉");
    }
}
