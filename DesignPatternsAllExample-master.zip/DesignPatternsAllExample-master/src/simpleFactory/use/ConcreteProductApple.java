package simpleFactory.use;

/**
 * 具体产品角色-苹果
 * Created by LinkinStar
 */
public class ConcreteProductApple implements Product {
    public void dis(){
        System.out.println("苹果");
    }
}
