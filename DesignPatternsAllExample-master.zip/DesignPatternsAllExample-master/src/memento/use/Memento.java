package memento.use;

/**
 * 备忘录
 * Created by LinkinStar
 */
public class Memento {

    public int x;
    public int y;

    public Memento(int x, int y){
        this.x = x;
        this.y = y;
    }
}
