package mediator.use;

/**
 * 抽象中介者
 * Created by LinkinStar
 */
public interface Mediator {
    void morning();
    void evening();
}
