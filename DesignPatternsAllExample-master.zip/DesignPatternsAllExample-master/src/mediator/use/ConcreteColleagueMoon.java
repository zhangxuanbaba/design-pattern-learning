package mediator.use;

/**
 * 月亮
 * Created by LinkinStar
 */
public class ConcreteColleagueMoon {

    public static void rise() {
        System.out.println("月亮升起");
    }

    public static void down() {
        System.out.println("月亮下降");
    }
}
