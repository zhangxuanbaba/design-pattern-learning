package mediator.use;

/**
 * 人
 * Created by LinkinStar
 */
public class ConcreteColleagueMan {

    public static void getUp() {
        System.out.println("人们起床了");
    }

    public static void goBed() {
        System.out.println("人们睡觉了");
    }
}
