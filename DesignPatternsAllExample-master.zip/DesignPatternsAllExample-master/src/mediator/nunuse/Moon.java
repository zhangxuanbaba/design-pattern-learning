package mediator.nunuse;

/**
 * 月亮
 * Created by LinkinStar
 */
public class Moon {

    public static void rise() {
        System.out.println("月亮升起");
    }

    public static void down() {
        System.out.println("月亮下降");
    }
}
