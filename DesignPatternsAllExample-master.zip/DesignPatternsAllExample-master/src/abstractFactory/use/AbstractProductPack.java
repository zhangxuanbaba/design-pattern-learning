package abstractFactory.use;

/**
 * 抽象产品角色-包装
 * Created by LinkinStar
 */
public interface AbstractProductPack {
    void dis();
}
