package abstractFactory.use;

/**
 * 具体产品角色-苹果
 * Created by LinkinStar
 */
public class ConcreteProductApple implements AbstractProductFruit {
    public void dis(){
        System.out.println("苹果");
    }
}
