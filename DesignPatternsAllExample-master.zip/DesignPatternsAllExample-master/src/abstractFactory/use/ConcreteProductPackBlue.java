package abstractFactory.use;

/**
 * 具体产品角色-蓝色包装
 * Created by LinkinStar
 */
public class ConcreteProductPackBlue implements AbstractProductPack {
    public void dis(){
        System.out.print("蓝色包装");
    }
}
