package abstractFactory.use;

/**
 * 抽象产品角色-水果
 * Created by LinkinStar
 */
public interface AbstractProductFruit {
    void dis();
}
