package strategy.oop.nonuse.interfaces;

/**
 * 策略A实现方案接口
 * Created by LinkinStar
 */
public interface ISolutionA {
    int caculate(int data);
}
