package templateMethod.use;

/**
 * 奶茶
 * Created by LinkinStar
 */
public class MilkyTea extends AbstractClass {

    @Override
    void addIngredient() {
        System.out.print("加入奶茶粉；");
    }

}
