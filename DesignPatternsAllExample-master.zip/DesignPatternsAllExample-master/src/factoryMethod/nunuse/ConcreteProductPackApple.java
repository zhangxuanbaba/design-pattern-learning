package factoryMethod.nunuse;

/**
 * 具体产品角色-包装苹果
 * Created by LinkinStar
 */
public class ConcreteProductPackApple implements Product {
    public void dis(){
        System.out.println("包装苹果");
    }
}
