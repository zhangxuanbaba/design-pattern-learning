package factoryMethod.nunuse;

/**
 * 抽象产品角色
 * Created by LinkinStar
 */
public interface Product {
    void dis();
}
