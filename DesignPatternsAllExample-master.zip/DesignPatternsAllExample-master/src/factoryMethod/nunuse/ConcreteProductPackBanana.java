package factoryMethod.nunuse;

/**
 * 具体产品角色-包装香蕉
 * Created by LinkinStar
 */
public class ConcreteProductPackBanana implements Product {
    public void dis(){
        System.out.println("包装香蕉");
    }
}
