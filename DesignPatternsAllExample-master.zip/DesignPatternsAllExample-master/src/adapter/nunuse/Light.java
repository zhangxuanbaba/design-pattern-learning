package adapter.nunuse;

/**
 * 灯光
 * Created by LinkinStar
 */
public interface Light {
    /**
     * 点亮
     */
    void Light();
}
