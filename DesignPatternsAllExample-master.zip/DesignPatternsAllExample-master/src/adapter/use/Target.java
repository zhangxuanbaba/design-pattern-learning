package adapter.use;

/**
 * 目标抽象类-灯光
 * Created by LinkinStar
 */
public interface Target {
    /**
     * 点亮
     */
    void Light();
}
