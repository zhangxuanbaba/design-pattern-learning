package adapter.use;

/**
 * 手电筒
 * Created by LinkinStar
 */
public class Torch {
    public String light(){
        return "手电筒发光";
    }
}
