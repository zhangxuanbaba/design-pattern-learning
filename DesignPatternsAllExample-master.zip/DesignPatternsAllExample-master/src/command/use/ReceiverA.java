package command.use;

/**
 * 需要被控制的机器A
 * Created by LinkinStar
 */
public class ReceiverA {
    public void start(){
        System.out.println("机器A开启...");
    }
}
