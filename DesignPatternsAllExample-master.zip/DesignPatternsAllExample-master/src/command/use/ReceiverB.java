package command.use;

/**
 * 需要被控制的机器B
 * Created by LinkinStar
 */
public class ReceiverB {
    public void start(){
        System.out.println("机器B开启...");
    }
}
