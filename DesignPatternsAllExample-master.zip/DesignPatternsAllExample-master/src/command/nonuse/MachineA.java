package command.nonuse;

/**
 * 需要被控制的机器A
 * Created by LinkinStar
 */
public class MachineA {
    public void start(){
        System.out.println("机器A开启...");
    }
}
