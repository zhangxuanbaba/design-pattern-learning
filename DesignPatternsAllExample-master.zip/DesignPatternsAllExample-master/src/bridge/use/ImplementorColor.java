package bridge.use;

/**
 * 实现类接口-颜色
 * Created by LinkinStar
 */
public interface ImplementorColor {
    void color();
}
