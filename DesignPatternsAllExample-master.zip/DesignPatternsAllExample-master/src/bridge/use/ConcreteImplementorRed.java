package bridge.use;

/**
 * 具体实现类-红色
 * Created by LinkinStar
 */
public class ConcreteImplementorRed implements ImplementorColor {
    @Override
    public void color() {
        System.out.println("红色");
    }
}
