package bridge.use;

/**
 * 具体实现类-蓝色
 * Created by LinkinStar
 */
public class ConcreteImplementorBlue implements ImplementorColor {
    @Override
    public void color() {
        System.out.println("蓝色");
    }
}
