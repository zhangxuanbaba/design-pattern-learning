这个项目将包含大部分设计模式的例子（更新中）<br>
1、设计模式学习的笔记<br>
2、src目录下每一个包，表示一种设计模式<br>
3、每一种设计模式包下，有一个ReadMe文件用于说明该设计模式<br>
4、nouse下为不使用设计模式的代码<br>
5、use下为使用设计模式的代码<br>


目录<br>
策略模式：strategy<br>
观察者模式：observer<br>
装饰模式：decorator<br>
简单工厂模式：simpleFactory<br>
工厂方法模式：factoryMethod<br>
抽象工厂模式：abstractFactory<br>
单例模式：singleton<br>
命令模式：command<br>
适配器模式：adapter<br>
外观模式：facade<br>
模板方法模式：templateMethod<br>
迭代器模式：iterator<br>
组合模式：composite<br>
状态模式：state<br>
代理模式：proxy<br>
桥接模式：bridge<br>
建造者模式：builder<br>
职责链模式：chainOfResponsibility<br>
享元模式：flyweight<br>
解释器模式：interpreter<br>
中介者模式：mediator<br>
备忘录模式：memento<br>
原型模式：prototype<br>
访问者模式：visitor<br>



<br><br><br><br><br><br><br><br>












#并非所有情况都适合设计模式，在没有足够的经验前，多阅读一些其他实际源码的例子或许能给你更多的启发<br>
本人可能对一些设计模式理解有问题，如果写的不正确，还请高手指出，万分感谢
